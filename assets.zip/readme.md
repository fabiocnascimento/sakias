Documentação do desenvolvimento do sistema de edição de assinatura de e-mail para o grupo de empresas, Center Festas, Deccora e Addorna.
